//go:binary-only-package
package compiler

import (
	_ "bytes"
	_ "encoding/json"
	_ "errors"
	_ "fmt"
	_ "io/ioutil"
	_ "os/exec"
	_ "regexp"
	_ "strconv"
	_ "strings"
)
