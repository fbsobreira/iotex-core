//go:binary-only-package
package prque

import (
	_ "container/heap"
)
