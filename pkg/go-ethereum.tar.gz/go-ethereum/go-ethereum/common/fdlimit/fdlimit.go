//go:binary-only-package
package fdlimit

import (
	_ "errors"
	_ "syscall"
)
