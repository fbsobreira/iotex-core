//go:binary-only-package
package math

import (
	_ "fmt"
	_ "math/big"
	_ "strconv"
)
