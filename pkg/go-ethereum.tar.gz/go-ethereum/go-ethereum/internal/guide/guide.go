//go:binary-only-package
package guide
