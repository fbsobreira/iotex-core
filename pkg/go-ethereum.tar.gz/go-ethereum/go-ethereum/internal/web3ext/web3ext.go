//go:binary-only-package
package web3ext
