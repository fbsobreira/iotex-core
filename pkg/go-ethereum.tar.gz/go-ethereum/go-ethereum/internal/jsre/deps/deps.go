//go:binary-only-package
package deps

import (
	_ "bytes"
	_ "compress/gzip"
	_ "fmt"
	_ "io"
	_ "io/ioutil"
	_ "os"
	_ "path/filepath"
	_ "strings"
	_ "time"
)
