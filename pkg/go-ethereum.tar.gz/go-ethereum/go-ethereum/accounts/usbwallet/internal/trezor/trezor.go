//go:binary-only-package
package trezor

import (
	_ "reflect"
	_ "fmt"
	_ "math"

	_ "github.com/golang/protobuf/protoc-gen-go/descriptor"
	_ "github.com/golang/protobuf/proto"
)
