//go:binary-only-package
package bn256

import (
	_ "crypto/rand"
	_ "errors"
	_ "io"
	_ "math/big"
)

