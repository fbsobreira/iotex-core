//go:binary-only-package
package bn256

import (
	_ "crypto/rand"
	_ "errors"
	_ "fmt"
	_ "io"
	_ "math/big"

	_ "golang.org/x/sys/cpu"
)
