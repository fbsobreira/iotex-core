//go:binary-only-package
package sha3

import (
	_ "encoding/binary"
	_ "crypto"
	_ "hash"
	_ "io"
	_ "unsafe"
)
