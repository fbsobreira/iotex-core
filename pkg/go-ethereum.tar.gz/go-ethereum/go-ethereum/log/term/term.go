//go:binary-only-package
package term

import (
	_ "syscall"
	_ "unsafe"

	_ "golang.org/x/sys/unix"
)
