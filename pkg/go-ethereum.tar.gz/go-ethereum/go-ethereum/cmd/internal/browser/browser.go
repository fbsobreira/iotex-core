//go:binary-only-package
package browser

import (
	_ "os"
	_ "os/exec"
	_ "runtime"
)
