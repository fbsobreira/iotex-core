//go:binary-only-package
package compiler

import (
	_ "errors"
	_ "fmt"

	_ "github.com/ethereum/go-ethereum/core/asm"
)
