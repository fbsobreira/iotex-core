//go:binary-only-package
package netutil

import (
	_ "bytes"
	_ "errors"
	_ "fmt"
	_ "net"
	_ "sort"
	_ "strings"
	_ "net"
	_ "os"
	_ "syscall"
)
