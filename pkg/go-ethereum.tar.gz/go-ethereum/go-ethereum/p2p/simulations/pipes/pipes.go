//go:binary-only-package
package pipes

import (
	_ "net"
)
