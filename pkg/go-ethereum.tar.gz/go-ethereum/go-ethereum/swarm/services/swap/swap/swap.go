//go:binary-only-package
package swap

import (
	_ "fmt"
	_ "math/big"
	_ "sync"
	_ "time"

	_ "github.com/ethereum/go-ethereum/swarm/log"
)
