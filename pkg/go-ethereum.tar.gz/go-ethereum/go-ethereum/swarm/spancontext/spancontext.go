//go:binary-only-package
package spancontext

import (
	_ "context"

	_ "github.com/opentracing/opentracing-go"
)
