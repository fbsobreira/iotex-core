//go:binary-only-package
package bitvector

import (
	_ "errors"
)
