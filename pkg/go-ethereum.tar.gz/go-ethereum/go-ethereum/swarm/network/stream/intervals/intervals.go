//go:binary-only-package
package intervals

import (
	_ "bytes"
	_ "fmt"
	_ "strconv"
	_ "sync"
)

