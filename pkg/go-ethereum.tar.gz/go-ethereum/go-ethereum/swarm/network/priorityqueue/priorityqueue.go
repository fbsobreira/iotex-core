//go:binary-only-package
package priorityqueue

import (
	_ "context"
	_ "errors"

	_ "github.com/ethereum/go-ethereum/log"
)
