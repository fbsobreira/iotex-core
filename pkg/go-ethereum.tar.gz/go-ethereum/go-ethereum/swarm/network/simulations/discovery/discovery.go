//go:binary-only-package
package discovery
