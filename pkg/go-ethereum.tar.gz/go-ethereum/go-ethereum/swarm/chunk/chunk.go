//go:binary-only-package
package chunk
