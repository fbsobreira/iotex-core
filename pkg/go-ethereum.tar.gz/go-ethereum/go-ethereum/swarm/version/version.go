//go:binary-only-package
package version

import (
	_ "fmt"
)
