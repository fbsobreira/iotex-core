//go:binary-only-package
package sctx

import (
	_ "context"
)
