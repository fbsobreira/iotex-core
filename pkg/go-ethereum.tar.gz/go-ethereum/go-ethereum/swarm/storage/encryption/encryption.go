//go:binary-only-package
package encryption

import (
	_ "crypto/rand"
	_ "encoding/binary"
	_ "fmt"
	_ "hash"
	_ "sync"
)
