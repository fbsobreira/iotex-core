//go:binary-only-package
package mock

import (
	_ "errors"
	_ "io"

	_ "github.com/ethereum/go-ethereum/common"
)
