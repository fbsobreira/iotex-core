//go:binary-only-package
package bmt

import (
	_ "fmt"
	_ "hash"
	_ "strings"
	_ "sync"
	_ "sync/atomic"
)
