//go:binary-only-package
package multihash

import (
	_ "bytes"
	_ "encoding/binary"
	_ "errors"
	_ "fmt"
)
